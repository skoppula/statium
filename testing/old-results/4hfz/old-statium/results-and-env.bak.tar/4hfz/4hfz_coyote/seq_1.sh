#PBS -S /bin/sh
./build_test.py -statium_sidechain 4hfz 4hfz_coyote/seq_1.txt 4hfz_coyote 1
