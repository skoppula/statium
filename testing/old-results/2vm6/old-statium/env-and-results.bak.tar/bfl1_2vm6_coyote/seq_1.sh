#PBS -S /bin/sh
./build_test.py -statium_sidechain bfl1_2vm6 bfl1_2vm6_coyote/seq_1.txt bfl1_2vm6_coyote 1
